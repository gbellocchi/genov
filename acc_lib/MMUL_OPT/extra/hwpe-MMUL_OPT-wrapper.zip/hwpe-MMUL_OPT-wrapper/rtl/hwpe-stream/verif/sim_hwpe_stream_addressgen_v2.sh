#!/bin/bash
set -e
vsim vopt_tb_hwpe_stream_addressgen_v2
