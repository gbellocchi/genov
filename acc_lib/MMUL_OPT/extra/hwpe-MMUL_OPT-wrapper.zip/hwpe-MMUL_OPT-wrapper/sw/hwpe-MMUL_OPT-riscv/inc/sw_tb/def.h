// Author: Gianluca Bellocchi
#define WIDTH 40
#define HEIGHT 30
#define NUM_UNFILTERED WIDTH*HEIGHT
#define COEFFS_DIM 4