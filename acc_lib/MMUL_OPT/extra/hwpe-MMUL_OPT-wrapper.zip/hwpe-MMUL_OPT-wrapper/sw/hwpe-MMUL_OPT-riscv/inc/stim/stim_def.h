/* 
 * Authors:  Gianluca Bellocchi <gianluca.bellocchi@unimore.it>
 */

#define STIM_DIM    4096
#define STRIPE_LEN  4096